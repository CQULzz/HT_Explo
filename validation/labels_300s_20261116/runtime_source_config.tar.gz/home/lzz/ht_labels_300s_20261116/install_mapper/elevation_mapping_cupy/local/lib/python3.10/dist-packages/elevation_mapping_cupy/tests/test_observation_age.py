"""Regression checks for actual direct-observation ages (requires CUDA)."""
from pathlib import Path
from types import SimpleNamespace
import threading

import cupy as cp
import numpy as np
import pytest

from elevation_mapping_cupy import ElevationMap, Parameter


@pytest.fixture
def elevation_map(tmp_path):
    package_dir = Path(__file__).resolve().parents[3]
    plugin_file = tmp_path / "plugins.yaml"
    plugin_file.write_text("min_filter:\n  enable: false\n")
    param = Parameter(
        use_chainer=False,
        resolution=0.1,
        map_length=4.0,
        weight_file=str(package_dir / "config/core/weights.dat"),
        plugin_config_file=str(plugin_file),
        enable_visibility_cleanup=False,
        enable_drift_compensation=False,
        enable_overlap_clearance=False,
        initial_variance=1000.0,
    )
    param.subscriber_cfg = {"scan": {"data_type": "pointcloud"}}
    param.update()
    return ElevationMap(param)


def integrate(elevation_map, points, stamp):
    elevation_map.input_pointcloud(
        np.asarray(points, dtype=np.float32), ["x", "y", "z"],
        np.eye(3, dtype=np.float32), np.zeros(3, dtype=np.float32),
        0.0, 0.0, observation_stamp=stamp,
    )


def published_age(elevation_map, now):
    data = np.empty((elevation_map.cell_n - 2, elevation_map.cell_n - 2), np.float32)
    elevation_map.get_observation_age_ref(now, data)
    return data


def test_retained_cells_age_from_source_time_and_keep_epoch_precision(elevation_map):
    epoch = 1_792_036_800.0
    integrate(elevation_map, [[1.0, 0.0, -0.75]], epoch + 0.125)
    first_stamp = elevation_map.observation_stamps.get()
    assert np.isfinite(first_stamp).sum() == 1
    np.testing.assert_allclose(published_age(elevation_map, epoch + 0.25)[np.isfinite(published_age(elevation_map, epoch + 0.25))], [0.125], atol=1e-7)

    # Another observed cell and arbitrary legacy timer ticks cannot renew the
    # existing cell. A publication should never modify either source stamp.
    integrate(elevation_map, [[-1.0, 0.0, -0.75]], epoch + 2.125)
    for _ in range(17):
        elevation_map.update_time()
    age = published_age(elevation_map, epoch + 3.25)
    np.testing.assert_allclose(np.sort(age[np.isfinite(age)]), [1.125, 3.125], atol=1e-7)
    assert np.isnan(age).sum() == age.size - 2
    np.testing.assert_array_equal(elevation_map.observation_stamps.get()[np.isfinite(first_stamp)], first_stamp[np.isfinite(first_stamp)])


def test_rejected_outliers_do_not_count_as_observation(elevation_map):
    integrate(elevation_map, [[1.0, 0.0, -0.75]], 100.0)
    # A geometrically valid but inconsistent height is rejected by the actual
    # fusion kernel; seeing it is not an accepted observation of this surface.
    integrate(elevation_map, [[1.0, 0.0, -0.25]], 102.0)
    integrate(elevation_map, [[1.0, 0.0, 3.0]], 103.0)
    age = published_age(elevation_map, 104.0)
    np.testing.assert_allclose(age[np.isfinite(age)], [4.0])


def test_shifting_clearing_and_out_of_order_source_stamps(elevation_map):
    integrate(elevation_map, [[1.0, 0.0, -0.75]], 100.0)
    integrate(elevation_map, [[1.0, 0.0, -0.75]], 99.0)
    np.testing.assert_allclose(published_age(elevation_map, 101.0)[np.isfinite(published_age(elevation_map, 101.0))], [1.0])
    before = elevation_map.observation_stamps.get()
    elevation_map.shift_map_xy(cp.asarray([1, -2]))
    expected = np.roll(before, [1, -2], axis=(1, 2))
    expected[:, :1, :] = np.nan
    expected[:, :, -2:] = np.nan
    np.testing.assert_array_equal(elevation_map.observation_stamps.get(), expected)
    elevation_map.clear()
    assert np.isnan(elevation_map.observation_stamps.get()).all()
    assert np.isnan(published_age(elevation_map, 101.0)).all()


def test_ros_wire_preserves_world_position_for_height_and_age(elevation_map):
    # Exercise the actual ROS publisher using a real CUDA-fused point. The
    # getter already flips axes; flipping again in the wrapper would place
    # this observation on the opposite side of the vehicle.
    from elevation_mapping_cupy.elevation_mapping_ros import ElevationMappingNode
    from rclpy.time import Time

    source_point = np.asarray([1.01, 0.31, -0.75], np.float32)
    integrate(elevation_map, [source_point], 100.125)
    published = []
    node = SimpleNamespace(
        map_translation=True, map=elevation_map,
        last_integrated_stamp=Time(seconds=100.125),
        map_access_lock=threading.RLock(),
        map_data=np.empty((elevation_map.cell_n - 2, elevation_map.cell_n - 2), np.float32),
        map_frame="map",
        publisher_configs={"test": {"layers": ["elevation", "observation_age"], "basic_layers": ["elevation"]}},
        map_publishers={"test": SimpleNamespace(publish=published.append)},
        get_clock=lambda: SimpleNamespace(now=lambda: Time(seconds=100.25)),
    )
    ElevationMappingNode.publish_map(node, "test")
    msg = published[0]
    n = elevation_map.cell_n - 2
    height = np.asarray(msg.data[msg.layers.index("elevation")].data).reshape((n, n), order="F")
    age = np.asarray(msg.data[msg.layers.index("observation_age")].data).reshape((n, n), order="F")
    i, j = np.argwhere(np.isfinite(height))[0]
    world_xy = np.asarray([
        msg.info.pose.position.x + (n / 2 - i - 0.5) * msg.info.resolution,
        msg.info.pose.position.y + (n / 2 - j - 0.5) * msg.info.resolution,
    ])
    assert np.linalg.norm(world_xy - source_point[:2]) <= msg.info.resolution / np.sqrt(2) + 1e-6
    # The existing finite-variance zero prior shifts this first fused height
    # slightly; it must still be within a tenth of a millimeter of the point.
    assert height[i, j] == pytest.approx(-0.75, abs=1e-4)
    assert age[i, j] == pytest.approx(0.0)
    assert msg.header.stamp.sec == 100 and msg.header.stamp.nanosec == 125_000_000
    # Re-publishing without another integrated scan cannot renew freshness.
    node.get_clock = lambda: SimpleNamespace(now=lambda: Time(seconds=110.0))
    ElevationMappingNode.publish_map(node, "test")
    assert published[-1].header.stamp == msg.header.stamp
    np.testing.assert_array_equal(np.isfinite(height), np.isfinite(age))


def test_registered_cloud_qos_is_reliable_without_breaking_raw_sensor_compatibility():
    from elevation_mapping_cupy.elevation_mapping_ros import _pointcloud_qos
    from rclpy.qos import ReliabilityPolicy

    registered = _pointcloud_qos({"registered_cloud_sensor_frame":"sensor"}, False)
    assert registered.reliability == ReliabilityPolicy.RELIABLE
    assert registered.depth == 30
    raw = _pointcloud_qos({}, False)
    assert raw.reliability == ReliabilityPolicy.BEST_EFFORT
    assert raw.depth == 5
    offline = _pointcloud_qos({}, True)
    assert offline.reliability == ReliabilityPolicy.RELIABLE
    assert offline.depth == 100


@pytest.mark.parametrize("offline", [False, True])
def test_pose_timer_never_waits_for_tf_or_uses_future_replay_pose(offline):
    from elevation_mapping_cupy.elevation_mapping_ros import ElevationMappingNode
    from geometry_msgs.msg import TransformStamped
    from rclpy.time import Time

    looked_up = []
    moved = []
    transform = TransformStamped()
    transform.transform.rotation.w = 1.0
    transform.transform.translation.x = 3.0
    def lookup(target, source, stamp, timeout):
        looked_up.append((stamp.nanoseconds, timeout.nanoseconds))
        return transform
    node = SimpleNamespace(
        last_stamp=Time(seconds=100.125), offline_tf_bag="recorded_bag" if offline else "",
        map_frame="map", base_frame="sensor", map_access_lock=threading.RLock(),
        tf_buffer=SimpleNamespace(lookup_transform=lookup),
        map=SimpleNamespace(move_to=lambda p,r:moved.append((p,r))),
        transform_to_arrays=ElevationMappingNode.transform_to_arrays,
    )
    ElevationMappingNode.update_pose(node)
    assert looked_up == [(100_125_000_000 if offline else 0, 0)]
    assert moved[0][0][0] == 3.0


def test_map_publication_runs_while_maintenance_callback_is_busy():
    """A long pose timer must not occupy the map publisher callback group."""
    import time
    import rclpy
    from rclpy.context import Context
    from rclpy.node import Node
    from rclpy.callback_groups import MutuallyExclusiveCallbackGroup
    from rclpy.executors import MultiThreadedExecutor
    from elevation_mapping_cupy.elevation_mapping_ros import ElevationMappingNode

    busy, release, published = (threading.Event() for _ in range(3))
    class Timers(Node):
        register_publishers = ElevationMappingNode.register_publishers
        register_timers = ElevationMappingNode.register_timers
        timed_timer = ElevationMappingNode.timed_timer
        def __init__(self, context):
            super().__init__('map_timer_scheduling_test', context=context)
            self.timer_callback_group = MutuallyExclusiveCallbackGroup()
            self.publish_callback_group = MutuallyExclusiveCallbackGroup()
            self.publisher_configs = {'test': {'fps': 50}}
            self.map_publishers, self.map_timers, self.timer_profile = {}, [], {}
            self.config = {'update_pose_fps': 50, 'update_variance_fps': 1, 'time_interval': 1}
            self.register_publishers()
            self.register_timers()
        def update_pose(self):
            busy.set()
            release.wait(timeout=2)
        def update_variance(self): pass
        def update_time(self): pass
        def write_processing_stats(self): pass
        def publish_map(self, name):
            if busy.is_set() and not release.is_set(): published.set()
    context = Context()
    rclpy.init(context=context)
    node = Timers(context)
    executor = MultiThreadedExecutor(num_threads=3, context=context)
    executor.add_node(node)
    try:
        deadline = time.monotonic() + 1
        while not published.is_set() and time.monotonic() < deadline:
            executor.spin_once(timeout_sec=.02)
        assert busy.is_set()
        assert published.is_set(), 'Publication was starved behind the blocked maintenance timer'
    finally:
        release.set()
        from elevation_mapping_cupy.elevation_mapping_ros import _stop_executor
        _stop_executor(executor)
        node.destroy_node()
        context.try_shutdown()
