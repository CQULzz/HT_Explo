"""CUDA regressions for snapshot-based elevation fusion, without ROS nodes.

The reference checks use scalar information-form Gaussian conditioning and
explicitly known inliers. They do not copy the GPU acceptance/reduction code.
Same-input repetitions compare actual state bits, including NaN payloads, rather
than rounded output or serialized-file hashes. No hardware/simulation is started.
"""
from pathlib import Path

import cupy as cp
import numpy as np
import pytest

from elevation_mapping_cupy import ElevationMap, Parameter


@pytest.fixture
def make_map(tmp_path, monkeypatch):
    monkeypatch.delenv("CUPY_DETERMINISTIC_FUSION", raising=False)
    package = Path(__file__).resolve().parents[3]
    plugins = tmp_path / "plugins.yaml"
    plugins.write_text("min_filter:\n  enable: false\n")

    def factory(*, deterministic=True, **settings):
        values = dict(
            use_chainer=False, resolution=.1, map_length=4.,
            weight_file=str(package / "config/core/weights.dat"),
            plugin_config_file=str(plugins), enable_drift_compensation=False,
            enable_overlap_clearance=False, enable_visibility_cleanup=False,
            enable_deterministic_fusion=deterministic,
        )
        values.update(settings)
        param = Parameter(**values)
        param.subscriber_cfg = {"scan": {"data_type": "pointcloud"}}
        param.update()
        mapping = ElevationMap(param)
        assert mapping.fusion_backend == ("deterministic" if deterministic else "legacy")
        return mapping

    return factory


def integrate(mapping, points, stamp=100., sensor_height=0.,
              position_noise=0., orientation_noise=0.):
    cloud = np.asarray(points, np.float32).reshape(-1, 3)
    untouched = cloud.tobytes()
    mapping.input_pointcloud(
        cloud, ["x", "y", "z"], np.eye(3, dtype=np.float32),
        np.asarray([0., 0., sensor_height], np.float32),
        position_noise, orientation_noise,
        observation_stamp=stamp,
    )
    cp.cuda.get_current_stream().synchronize()
    assert cloud.tobytes() == untouched, "Integrating must not rewrite caller point coordinates"


def cell(mapping, x, y):
    # Fixture coordinates lie well inside cells, avoiding float boundary ties.
    n, resolution = mapping.cell_n, mapping.resolution
    return int(x / resolution + n / 2), int(y / resolution + n / 2)


def seed(mapping, xy, height, variance, *, source_stamp=99., timer_age=2.):
    i, j = cell(mapping, *xy)
    mapping.elevation_map[0, i, j] = height
    mapping.elevation_map[1, i, j] = variance
    mapping.elevation_map[2, i, j] = 1.
    mapping.elevation_map[4, i, j] = timer_age
    mapping.elevation_map[5, i, j] = height
    mapping.elevation_map[6, i, j] = 0.
    mapping.normal_map[:, i, j] = cp.asarray([0., 0., 1.], cp.float32)
    mapping.observation_stamps[0, i, j] = source_stamp
    return i, j


def reference_batch(prior_mean, prior_variance, world_heights, sensor_heights, noise_factor):
    """Independent Gaussian information update, then documented batch average.

    Each accepted measurement conditions the same immutable prior. This is
    intentionally different from conditioning repeatedly on previous points.
    The experiment fixes the accepted set independently of this calculation.
    """
    world = np.asarray(world_heights, np.float64)
    measurement_variance = noise_factor * np.asarray(sensor_heights, np.float64) ** 2
    prior_precision = 1. / prior_variance
    measurement_precision = 1. / measurement_variance
    posterior_variance = 1. / (prior_precision + measurement_precision)
    posterior_mean = posterior_variance * (prior_mean * prior_precision + world * measurement_precision)
    return float(np.mean(posterior_mean)), float(np.mean(posterior_variance))


def state(mapping):
    return {name: cp.asnumpy(getattr(mapping, name)).copy()
            for name in ["elevation_map", "observation_stamps", "normal_map", "new_map",
                         "traversability_input", "traversability_buffer"]}


def assert_same_bits(actual, expected):
    assert actual.keys() == expected.keys()
    for name in actual:
        assert actual[name].shape == expected[name].shape
        assert actual[name].dtype == expected[name].dtype
        assert actual[name].tobytes() == expected[name].tobytes(), name


def ground_step_wall():
    xs = (np.arange(4, 15, dtype=float) + .37) * .1
    ys = (np.arange(-6, 7, dtype=float) + .37) * .1
    x, y = np.meshgrid(xs, ys, indexing="ij")
    heights = np.where(x < .9, 0., .3)
    heights[x > 1.3] = .7
    world = np.c_[x.ravel(), y.ravel(), heights.ravel()]
    sensor = world.copy()
    sensor[:, 2] -= .75
    return sensor.astype(np.float32), world


def test_batch_gaussian_reference_and_outliers_use_one_prior(make_map):
    mapping = make_map()
    xy, prior_h, prior_v = (.437, .137), -.4, .08
    i, j = seed(mapping, xy, prior_h, prior_v)
    known_inliers = np.asarray([-.45, -.4, -.3], np.float32)
    # All are geometrically valid. +0.1 exceeds the independently known
    # prior gate [-0.56,-0.24] and must not participate in fusion.
    samples = np.asarray([*known_inliers, .1], np.float32)
    integrate(mapping, [[*xy, z] for z in samples], stamp=100.125)
    expected_h, expected_v = reference_batch(prior_h, prior_v, known_inliers,
                                             known_inliers, mapping.param.sensor_noise_factor)
    assert float(mapping.new_map[2, i, j]) == len(known_inliers)
    assert float(mapping.elevation_map[0, i, j]) == pytest.approx(expected_h, abs=2e-7)
    assert float(mapping.elevation_map[1, i, j]) == pytest.approx(expected_v, abs=2e-8)
    assert float(mapping.observation_stamps[0, i, j]) == 100.125


def test_dense_outliers_cannot_widen_same_scan_acceptance(make_map):
    mapping = make_map()
    xy = (.437, .137)
    i, j = seed(mapping, xy, 0., .01)
    # Only 0.019 lies inside the immutable prior's +/-0.02 gate.
    # Legacy in-kernel outlier variance inflation makes other points eligible
    # during this very scan; this asserts the corrected semantic contract.
    n = 512
    heights = np.tile(np.asarray([.019, .025, .055, .09, .15], np.float32), n)
    integrate(mapping, np.c_[np.full(len(heights), xy[0]), np.full(len(heights), xy[1]), heights])
    expected_h, expected_v = reference_batch(0., .01, [.019], [.019], mapping.param.sensor_noise_factor)
    assert float(mapping.new_map[2, i, j]) == n
    assert float(mapping.elevation_map[0, i, j]) == pytest.approx(expected_h, abs=2e-7)
    assert float(mapping.elevation_map[1, i, j]) == pytest.approx(expected_v, abs=2e-8)


def test_rejected_only_scan_increases_variance_without_renewing_source_age(make_map):
    mapping = make_map()
    xy, h, v = (.437, .137), -.6, .02
    i, j = seed(mapping, xy, h, v, source_stamp=99.125)
    integrate(mapping, [[*xy, -.3]] * 4, stamp=103.5)
    assert float(mapping.new_map[2, i, j]) == 0
    assert float(mapping.elevation_map[0, i, j]) == pytest.approx(h, abs=1e-7)
    assert float(mapping.elevation_map[1, i, j]) == pytest.approx(v + 4 * mapping.param.outlier_variance, abs=1e-7)
    assert float(mapping.observation_stamps[0, i, j]) == 99.125


def test_never_observed_cell_recovers_from_real_point_not_ray_prior(make_map):
    mapping = make_map(enable_visibility_cleanup=True)
    xy = (1.037, .037)
    integrate(mapping, [[*xy, -.75]], stamp=100.125, sensor_height=.75)
    i, j = cell(mapping, *xy)
    assert float(mapping.elevation_map[2, i, j]) == 1.
    assert float(mapping.elevation_map[0, i, j]) == pytest.approx(0., abs=1e-7)
    assert int(cp.isfinite(mapping.observation_stamps).sum()) == 1
    assert float(mapping.observation_stamps[0, i, j]) == 100.125
    # Rays may give an unknown cell an upper bound. They must not turn that
    # bound into a measured surface or fabricate a direct-observation stamp.
    unknown = ~cp.isfinite(mapping.observation_stamps[0])
    assert int(unknown.sum()) > 100
    assert not bool((mapping.elevation_map[2][unknown] > .5).any())


def test_high_posterior_variance_does_not_claim_observation(make_map):
    mapping = make_map()
    xy = (1.037, .037)
    # A ground hit five metres below the sensor has measurement variance
    # 0.05 * 5^2 = 1.25. Conditioning the initial variance 10 gives 10/9,
    # above the existing max_variance=1. A candidate was integrated, but it
    # cannot become a valid measured surface or renew direct source age.
    integrate(mapping, [[*xy, -5.]], stamp=100.125, sensor_height=5.)
    i, j = cell(mapping, *xy)
    assert float(mapping.new_map[2, i, j]) == 1.
    assert float(mapping.elevation_map[2, i, j]) == 0.
    assert float(mapping.elevation_map[0, i, j]) == 0.
    assert float(mapping.elevation_map[1, i, j]) == mapping.param.initial_variance
    assert bool(cp.isnan(mapping.observation_stamps[0, i, j]))


def test_visibility_clears_stale_obstacle_but_not_same_scan_direct_hit(make_map):
    mapping = make_map(enable_visibility_cleanup=True, cleanup_cos_thresh=.3)
    fresh = seed(mapping, (.437, .037), .6, .05, source_stamp=99.)
    stale = seed(mapping, (.737, .037), .5, .05, source_stamp=98.)
    cloud = np.vstack([np.tile([.437, .037, -.15], (64, 1)),
                       np.tile([1.437, .037, -.75], (512, 1)),
                       np.tile([1.437, .037, -.45], (128, 1))])
    integrate(mapping, cloud, stamp=101.125, sensor_height=.75)
    assert float(mapping.elevation_map[2, *fresh]) == 1.
    assert float(mapping.elevation_map[0, *fresh]) == pytest.approx(.6, abs=1e-6)
    assert float(mapping.observation_stamps[0, *fresh]) == 101.125
    assert float(mapping.elevation_map[2, *stale]) == 0.
    assert float(mapping.observation_stamps[0, *stale]) == 98.
    assert float(mapping.elevation_map[6, *stale]) == 1.
    # The lower ray must win the upper-bound minimum, not whichever ray is
    # scheduled last. Its sampled height here lies below the high-ray bound.
    assert float(mapping.elevation_map[5, *stale]) < .45


def test_flat_ground_true_step_and_wall_remain_measured(make_map):
    mapping = make_map(enable_visibility_cleanup=True)
    cloud, world = ground_step_wall()
    for number in range(3):
        if number:
            mapping.param.time_interval = .8
            mapping.update_time()
            mapping.update_variance()
        integrate(mapping, cloud, stamp=100.125 + number, sensor_height=.75)
    measured = []
    for x, y, height in world:
        i, j = cell(mapping, x, y)
        assert float(mapping.elevation_map[2, i, j]) == 1.
        observed = float(mapping.elevation_map[0, i, j])
        assert observed == pytest.approx(height, abs=.002)
        assert float(mapping.observation_stamps[0, i, j]) == 102.125
        measured.append(observed)
    measured = np.asarray(measured)
    assert np.max(np.abs(measured[world[:, 2] == 0.])) < .002
    assert np.min(measured[world[:, 2] == .3]) > .298
    assert np.min(measured[world[:, 2] == .7]) > .698
    assert np.ptp(measured) > .698


def test_drift_uses_reproducible_mean_before_gaussian_conditioning(make_map):
    mapping = make_map(enable_drift_compensation=True,
                       min_height_drift_cnt=2,
                       position_noise_thresh=.01,
                       orientation_noise_thresh=.01,
                       drift_compensation_alpha=.5)
    samples = []
    cells = []
    for x in [.437, .637, .837]:
        for y in [-.163, .037, .237]:
            cells.append(seed(mapping, (x, y), -.62, .02))
            samples.append([x, y, -.6])
    integrate(mapping, samples, stamp=100.125, position_noise=.05)
    # All nine independent cells see the same +2cm measurement residual.
    # The documented 0.5 correction shifts each prior by +1cm before the
    # independent Gaussian measurement update. This is an analytic fixture,
    # not a comparison against another invocation of the implementation.
    expected_h, expected_v = reference_batch(-.61, .02, [-.6], [-.6],
                                             mapping.param.sensor_noise_factor)
    assert float(mapping.mean_error) == pytest.approx(.02, abs=5e-7)
    for i, j in cells:
        assert float(mapping.new_map[2, i, j]) == 1.
        assert float(mapping.elevation_map[0, i, j]) == pytest.approx(expected_h, abs=3e-7)
        assert float(mapping.elevation_map[1, i, j]) == pytest.approx(expected_v, abs=3e-8)
        assert float(mapping.observation_stamps[0, i, j]) == 100.125


@pytest.mark.parametrize("drift_enabled", [False, True], ids=["no_drift", "drift"])
def test_four_fresh_instances_match_every_state_layer_exactly(make_map, drift_enabled):
    cloud, _ = ground_step_wall()
    stress = np.vstack([np.tile([.437, .037, -.15], (64, 1)),
                        np.tile([1.437, .037, -.75], (512, 1)),
                        np.tile([1.437, .037, -.45], (128, 1)),
                        np.tile([.637, -.163, -.731], (512, 1)),
                        np.tile([.637, -.163, -.60], (512, 1))]).astype(np.float32)
    reference = None
    for repetition in range(4):
        mapping = make_map(enable_visibility_cleanup=True, cleanup_cos_thresh=.3,
                           enable_drift_compensation=drift_enabled,
                           min_height_drift_cnt=2,
                           position_noise_thresh=.01,
                           orientation_noise_thresh=.01,
                           drift_compensation_alpha=.5)
        snapshots = []
        for index, points in enumerate([cloud, stress, cloud, stress]):
            if index:
                mapping.param.time_interval = .8
                mapping.update_time()
                mapping.update_variance()
            integrate(mapping, points, stamp=100.125 + index, sensor_height=.75,
                      position_noise=.05, orientation_noise=.02)
            snapshots.append(state(mapping))
        assert int((mapping.elevation_map[2] > .5).sum()) > 100
        if reference is None:
            reference = snapshots
        else:
            for actual, expected in zip(snapshots, reference, strict=True):
                assert_same_bits(actual, expected)
