#!/usr/bin/env python3
#
# Copyright (c) 2022, Takahiro Miki. All rights reserved.
# Licensed under the MIT license. See LICENSE file in the project root for details.
#
"""ROS 2 wrapper for the CuPy elevation mapping core."""

from functools import partial
from typing import Any

import numpy as np
import rclpy
import yaml
from ament_index_python.packages import get_package_share_directory
from grid_map_msgs.msg import GridMap
from rclpy.duration import Duration
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from rclpy.time import Time
from scipy.spatial.transform import Rotation
from sensor_msgs.msg import PointCloud2
from sensor_msgs_py import point_cloud2
from std_msgs.msg import Float32MultiArray, MultiArrayDimension, MultiArrayLayout
from tf2_ros import Buffer, ConnectivityException, ExtrapolationException, LookupException, TransformListener

from elevation_mapping_cupy import ElevationMap, Parameter


def _load_yaml(path: str) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as stream:
        return yaml.safe_load(stream) or {}


def _resolve_package_paths(value: Any, share_dir: str) -> Any:
    if isinstance(value, str):
        return value.replace("$(rospack find elevation_mapping_cupy)", share_dir)
    if isinstance(value, list):
        return [_resolve_package_paths(item, share_dir) for item in value]
    if isinstance(value, dict):
        return {key: _resolve_package_paths(item, share_dir) for key, item in value.items()}
    return value


def _set_parameter_fields(param: Parameter, values: dict[str, Any]) -> None:
    aliases = {
        "drift_compensation_variance_inler": "drift_compensation_variance_inlier",
    }
    for key, value in values.items():
        field_name = aliases.get(key, key)
        if hasattr(param, field_name):
            setattr(param, field_name, value)


def _pointcloud_to_numpy(msg: PointCloud2, channels: list[str]) -> np.ndarray:
    points = point_cloud2.read_points(msg, field_names=channels, skip_nans=True)
    if isinstance(points, np.ndarray):
        if points.dtype.names:
            return np.column_stack([points[name] for name in channels]).astype(np.float32, copy=False)
        return np.asarray(points, dtype=np.float32)
    return np.asarray(list(points), dtype=np.float32)


class ElevationMappingNode(Node):
    def __init__(self) -> None:
        super().__init__("elevation_mapping")
        self.share_dir = get_package_share_directory("elevation_mapping_cupy")
        self.declare_parameter("core_param_file", f"{self.share_dir}/config/core/core_param.yaml")
        self.declare_parameter("setup_file", f"{self.share_dir}/config/core/example_setup.yaml")

        core_param_file = self.get_parameter("core_param_file").value
        setup_file = self.get_parameter("setup_file").value
        self.config = _resolve_package_paths({**_load_yaml(core_param_file), **_load_yaml(setup_file)}, self.share_dir)

        self.param = Parameter()
        _set_parameter_fields(self.param, self.config)
        self.param.subscriber_cfg = self.config.get("subscribers", self.param.subscriber_cfg)
        self.param.update()

        self.subscriber_configs = self.config.get("subscribers", {})
        self.publisher_configs = self.config.get("publishers", {})
        self.map_frame = self.config.get("map_frame", self.param.map_frame if hasattr(self.param, "map_frame") else "map")
        self.base_frame = self.config.get("base_frame", "base_link")

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.map = ElevationMap(self.param)
        self.map_data = np.zeros((self.map.cell_n - 2, self.map.cell_n - 2), dtype=np.float32)
        self.map_translation = None
        self.map_rotation = None
        self.last_stamp = None
        self.pointcloud_process_counter = 0

        self.pointcloud_subscriptions = []
        self.map_publishers = {}
        self.map_timers = []
        self.register_subscribers()
        self.register_publishers()
        self.register_timers()
        self.get_logger().info("[ElevationMappingCupy] ROS 2 node initialized")

    def register_subscribers(self) -> None:
        for key, config in self.subscriber_configs.items():
            if config.get("data_type") != "pointcloud":
                self.get_logger().warn(f"ROS 2 wrapper currently skips non-pointcloud subscriber [{key}]")
                continue
            topic_name = config["topic_name"]
            callback = partial(self.pointcloud_callback, sub_key=key)
            sub = self.create_subscription(PointCloud2, topic_name, callback, qos_profile_sensor_data)
            self.pointcloud_subscriptions.append(sub)
            self.get_logger().info(f"Subscribed to PointCloud2 topic: {topic_name}")

    def register_publishers(self) -> None:
        for name, config in self.publisher_configs.items():
            self.map_publishers[name] = self.create_publisher(GridMap, f"~/{name}", 1)
            fps = float(config.get("fps", 1.0))
            self.map_timers.append(self.create_timer(1.0 / fps, partial(self.publish_map, name)))

    def register_timers(self) -> None:
        self.create_timer(1.0 / float(self.config.get("update_variance_fps", 5.0)), self.update_variance)
        self.create_timer(1.0 / float(self.config.get("update_pose_fps", 10.0)), self.update_pose)
        self.create_timer(float(self.config.get("time_interval", 0.1)), self.update_time)

    def pointcloud_callback(self, msg: PointCloud2, sub_key: str) -> None:
        config = self.param.subscriber_cfg[sub_key]
        channels = ["x", "y", "z"] + config.get("channels", [])
        try:
            points = _pointcloud_to_numpy(msg, channels)
        except Exception as exc:
            self.get_logger().error(f"Failed to decode PointCloud2 for [{sub_key}]: {exc}")
            return
        if points.size == 0:
            return

        stamp = Time.from_msg(msg.header.stamp)
        self.last_stamp = stamp
        try:
            transform = self.tf_buffer.lookup_transform(
                self.map_frame,
                msg.header.frame_id,
                stamp,
                timeout=Duration(seconds=1.0),
            )
        except (LookupException, ConnectivityException, ExtrapolationException) as exc:
            try:
                transform = self.tf_buffer.lookup_transform(
                    self.map_frame,
                    msg.header.frame_id,
                    Time(),
                    timeout=Duration(seconds=0.2),
                )
            except (LookupException, ConnectivityException, ExtrapolationException):
                self.get_logger().warn(f"TF lookup failed for pointcloud [{sub_key}]: {exc}")
                return

        translation, rotation = self.transform_to_arrays(transform)
        self.map.input_pointcloud(points, channels, rotation, translation, 0, 0)
        self.pointcloud_process_counter += 1

    def update_pose(self) -> None:
        if self.last_stamp is None:
            return
        try:
            transform = self.tf_buffer.lookup_transform(
                self.map_frame,
                self.base_frame,
                self.last_stamp,
                timeout=Duration(seconds=1.0),
            )
        except (LookupException, ConnectivityException, ExtrapolationException):
            try:
                transform = self.tf_buffer.lookup_transform(
                    self.map_frame,
                    self.base_frame,
                    Time(),
                    timeout=Duration(seconds=0.2),
                )
            except (LookupException, ConnectivityException, ExtrapolationException):
                return

        translation, rotation = self.transform_to_arrays(transform)
        self.map.move_to(translation, rotation)
        self.map_translation = transform.transform.translation
        self.map_rotation = transform.transform.rotation

    def update_variance(self) -> None:
        self.map.update_variance()

    def update_time(self) -> None:
        self.map.update_time()

    def publish_map(self, name: str) -> None:
        if self.map_translation is None:
            return
        config = self.publisher_configs[name]
        msg = GridMap()
        msg.header.frame_id = self.map_frame
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.info.resolution = float(self.map.resolution)
        msg.info.length_x = float(self.map.map_length)
        msg.info.length_y = float(self.map.map_length)
        msg.info.pose.position.x = float(self.map_translation.x)
        msg.info.pose.position.y = float(self.map_translation.y)
        msg.info.pose.position.z = 0.0
        msg.info.pose.orientation.w = 1.0
        msg.basic_layers = list(config.get("basic_layers", []))

        for layer in config.get("layers", []):
            try:
                self.map.get_map_with_name_ref(layer, self.map_data)
            except Exception as exc:
                if layer in msg.basic_layers:
                    self.get_logger().warn(f"Missing basic layer [{layer}]: {exc}")
                continue
            msg.layers.append(layer)
            data = np.ascontiguousarray(self.map_data.T, dtype=np.float32)
            array = Float32MultiArray()
            n = int(data.shape[0])
            array.layout = MultiArrayLayout(
                dim=[
                    MultiArrayDimension(label="column_index", size=n, stride=n * n),
                    MultiArrayDimension(label="row_index", size=n, stride=n),
                ],
                data_offset=0,
            )
            array.data = data.reshape(-1).tolist()
            msg.data.append(array)

        msg.outer_start_index = 0
        msg.inner_start_index = 0
        self.map_publishers[name].publish(msg)

    @staticmethod
    def transform_to_arrays(transform) -> tuple[np.ndarray, np.ndarray]:
        t = transform.transform.translation
        q = transform.transform.rotation
        translation = np.array([t.x, t.y, t.z], dtype=np.float32)
        rotation = Rotation.from_quat([q.x, q.y, q.z, q.w]).as_matrix().astype(np.float32)
        return translation, rotation


def main(args=None) -> None:
    rclpy.init(args=args)
    node = ElevationMappingNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
